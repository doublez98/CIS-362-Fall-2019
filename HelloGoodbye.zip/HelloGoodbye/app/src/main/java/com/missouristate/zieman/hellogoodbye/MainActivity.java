package com.missouristate.zieman.hellogoodbye;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements OnClickListener {

    TextView greeting;
    ImageView elephant;
    Button button;
    Boolean hello; //Used boolean method to switch the hello and goodbye

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btn_clickMe);
        button.setOnClickListener(this);

        elephant = findViewById(R.id.iv_hello);

        greeting = findViewById(R.id.tv_hello);

        hello = true;
    }

    @Override
    public void onClick(View x) {
        if (x == button);
        {
            if (hello == true) //once button is pressed, will change to goodbye
            {
                elephant.setImageResource(R.drawable.goodbye);
                greeting.setText("Good Bye");
                hello = false;
            }
            else if (hello == false) //once button is pressed again, will change back to hello
            {
                elephant.setImageResource(R.drawable.hello);
                greeting.setText("Hello");
                hello = true;
            }
        }
    }
}

